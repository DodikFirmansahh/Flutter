package com.example.project1_flutter

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
